var g = {
	//打开窗口（不带参数）par为可选参数
	openModuleWin:function(module,con,par){
		if (typeof(par) == 'undefined') {
			par = {};
		}
		var reload=false;
		if(con=='login'){
			reload=true;
		}
		api.openWin({
			name: con,
			url: '../'+module+'/'+con+'.html',
			pageParam: par,
			reload:reload,
			slidBackEnabled:false
		});
	},
	//打开当前Window子窗口 bool,par为可选参数
	openFrame:function(con,top,hasbottom,bool,par){
		var len = arguments.length;
		if (len == 3) {
			bool = false;
			par = {};
		} else if (len == 4) {
			if (typeof(bool) == 'boolean') {
				par = {};
			} else {
				par = bool;
				bool = false;
			}
		}
		var bottom_h = 0;
		if(hasbottom){
			bottom_h = 49;
		}
		
		api.openFrame({
			name: con,
			url: './'+con+'.html',
			pageParam: par,
			rect:{
				x:0,
				y:top,
				w:'auto',
				h:'auto',
				marginBottom:bottom_h
			},
			bounces:bool,
			reload:false
		});
	},
	/* 打开Framegroup */
	openFrameGroup:function(groupName,topShift,frames,scroll){
		var scroll = false;
		if(scroll){
			scroll = true;
		}
		api.openFrameGroup({
			name:groupName,
			scrollEnabled: scroll,
			preload:4,
		    rect:{
		    	x: 0,
			    y: topShift,
			    w: 'auto',
			    h: 'auto',
			    //marginBottom: 51
		    },
		    index: 0,
			frames:frames
		})
	},
	/* FrameGroup下标切换时，frame切换的函数 */
	setFrameIndex:function(groupName,index_){
		api.setFrameGroupIndex({
			name:groupName,
			index:index_,
		});
	},
	//返回按钮，关闭当前窗口
	goback:function(){
		api.closeWin();
	},
	//window头部处理
	getHeader:function(header){
		var obj = $api.byId(header);
		if(api.systemType=="android"){
			$api.addCls(obj,'padt-15');
		}
		$api.fixIos7Bar(obj);
		var headerPos = $api.offset(obj);
		return headerPos;
	},
	//toast提醒
	toastMsg:function(msg,location){
		if(location == ''){
			location = 'middle';
		}
		else if(location == 1){
			location = 'bottom';
		}
		api.toast({
			msg:msg,
			duration:1500,
			location:location,
		});
	},
	//loading...
	showLoading:function(){
		api.showProgress({
			style: 'default',
			animationType: 'fade',
			title: 'Loading...',
		});
	},
	/* 
	 *ajax交互函数
	 *param data：提交数据
	 */
	goAjax:function(controller,data,callback,errCallback){
		api.ajax({
			url:serve_url+controller,
			method:'post',
			timeout:30,
			dataType:'json',
			returnAll:false,
			data:{
				values:data
			}
		},function(ret,err){
			if(ret){
				if(ret.ret == 1){
					callback(ret);
				}else{
					if(errCallback){
						errCallback(ret);
						return;
					}
					g.toastMsg(ret.err);
				}
			}else{
				api.hideProgress();
				api.actionSheet({
				    cancelTitle: '网络连接失败..',
				    buttons: ['再试一下','退出'],
				    style:{
				        fontNormalColor: '#666',
				        fontPressColor: '#666'
				    }
				},function(ret,err){
				    if(ret.buttonIndex==1){
				        location.reload();
				    }else if(ret.buttonIndex==2){
				        api.closeWidget({
				        	retData: {name:'closeWidget'},
				        	silent:true
				        });
				    }
				});
				// var line=g.connectCheck();
				// if(!line){
				// 	g.toastMsg('not internet');
				// 	return;
				// }
				// g.reload();
			}
		});
	},
	/* 
	 *检测网络连接
	 */
	connectCheck:function(){
		var pass = true;
		var connectionType = api.connectionType;
		if(connectionType == 'none'){
			pass = false;
		}
		return pass;
	},
	/*向已打开的窗体执行脚本，也可用于传值-开始
	* win :指定的窗体名称
	* frame:窗体中的frame名称
	* callback :要执行的操作
	*data:回调函数的参数
	*/
	execScript:function(win,frame,callback,data){
		if(!data){
			data={};
		}
		var data=$api.jsonToStr(data);
		var jsfun='g.jsFun('+callback+','+data+')';
		api.execScript({
		    name:win,
		    frameName: frame,
		    script: jsfun
		});
	},
	jsFun:function(callback,data){
		callback(data);
	},
	/*向已打开的窗体执行脚本，也可用于传值-结束*/
	/*页面涉及到ajax数据交互的按钮操作*/
	showProgress:function(msg,modal){
		var type=true;
		if(modal){
			type=modal;
		}
		api.showProgress({
			style : 'default',
			animationType : 'fade',
			title : msg,
			modal : type
		});
	}
}